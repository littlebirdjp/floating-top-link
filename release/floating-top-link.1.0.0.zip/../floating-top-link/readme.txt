=== Plugin Name ===
Contributors: Yusuke Takahashi
Tags:
Requires at least: 4.3
Tested up to: 4.4
Stable tag: 1.0.0
License:     GNU General Public License v2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==

A simple plugin adding a link button to the top of a page.
The design of a link button is based on the Material Design guideline.

[This Plugin published on GitHub.](https://github.com/littlebirdjp/floating-top-link)

== Installation ==

1. Upload the entire `floating-top-link` folder to the `/wp-content/plugins/` directory.
1. Activate the plugin through the 'Plugins' menu in WordPress.

== Changelog ==

= 1.0 =
* first release.
